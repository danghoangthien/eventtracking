<?php

namespace Hyper\Adops\APIBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class HyperAdopsAPIBundle extends Bundle
{
}