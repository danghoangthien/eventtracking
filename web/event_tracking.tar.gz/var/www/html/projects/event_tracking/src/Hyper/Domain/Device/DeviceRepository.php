<?php 

namespace Hyper\Domain\Device;

interface DeviceRepository {

}