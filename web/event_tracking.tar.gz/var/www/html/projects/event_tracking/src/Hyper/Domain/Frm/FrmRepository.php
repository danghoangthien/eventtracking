<?php 

namespace Hyper\Domain\Frm;

interface FrmRepository {

}