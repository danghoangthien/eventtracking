<?php 

namespace Hyper\Domain\Application;

interface ApplicationRepository {

}