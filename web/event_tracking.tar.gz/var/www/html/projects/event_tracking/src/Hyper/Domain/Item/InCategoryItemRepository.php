<?php 

namespace Hyper\Domain\Item;

interface InCategoryItemRepository {

}