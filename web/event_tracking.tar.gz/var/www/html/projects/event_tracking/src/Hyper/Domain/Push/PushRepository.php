<?php 

namespace Hyper\Domain\Push;

interface PushRepository {

}