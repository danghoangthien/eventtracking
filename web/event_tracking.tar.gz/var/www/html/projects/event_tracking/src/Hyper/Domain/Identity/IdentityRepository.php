<?php 

namespace Hyper\Domain\Identity;

interface IdentityRepository {

}