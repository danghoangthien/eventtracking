<?php
namespace Hyper\EventBundle\Controller;

use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Symfony\Component\DependencyInjection\ContainerInterface;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Filesystem\Filesystem;
use Symfony\Component\Filesystem\Exception\IOExceptionInterface;
use Symfony\Component\HttpFoundation\File\File;

use Hyper\Domain\Device\Device;

class StorageControllerV4 extends Controller
{
    public $postBackProvider = null;
    /**
    * @param ContainerInterface $container
    */
    public function __construct(ContainerInterface $container)
    {
        $this->container = $container;
        $errorAudit = $this->container->get('error_audit_service');
        $errorAudit->init('Redshift');
        register_shutdown_function(array($errorAudit, 'log'));
    }
    
    public function indexAction(Request $request)
    {
        //return new Response('This is postback version 2<hr/>');
        $providerId = $request->get('provider');

        // 2015-08-10 - Ding Dong : to capture the value of app_name (app_id) and event_type
        $appId = $request->get('app_name');
        $eventType = $request->get('event_type');

        // 2015-08-20 - Ding Dong : Added to capture the hostname of the server; to be used for the status updates
        $host_name = $request->getHttpHost();

        $supportProvider = $this->getPostBackProviders();
        if(!empty($providerId) && array_key_exists($providerId,$supportProvider)) {
            $this->postBackProvider = $supportProvider[$providerId];
        }
        $content = array();
        $isPostWithJsonBody = $this->isPostWithJsonBody($request);
        if ($isPostWithJsonBody) {
            $content = $this->getValidContent($request);
            if(!empty($content)){
                $filePath = $this->storeEventS3FromAPI($request);
                //$this->storeEventMemCached($content);
                if(!empty($filePath)){
                    /*
                    $metaData = array();
                    $metaData['s3_log_file'] = $filePath;
                    $redshift = $this->get('redshift_service');
                    $redshift->storeLogEventToRedshift($providerId,$content,$metaData);
                    */
                    return new Response(
                        json_encode(
                            array(
                                'file_path' => $filePath
                            )
                        )
                    );
                }
            }
        } else {
            //improve with Rest API standard later
            return new Response(
                json_encode(
                    array(
                        'error'=>'bad request',
                        'code'=>'400'
                    )
                )
            );
        }
        
    }
    
    protected function isPostWithJsonBody(Request $request)
    {
        $contentType = $request->headers->get('Content-Type');
        $method = $request->getMethod();
        //$logger = $this->get('logger');
        //$logger->info('result contentType'.$contentType);
        //$logger->info('result method'.$method);
        return ($contentType == 'application/json' && $method == 'POST');
    }
    
    
    protected function isPurchaseEvent($content)
    {
        return (!empty($content['event_name']) && strpos($content['event_name'],'purchase')!==false);
    }
    
    protected function getValidContent(Request $request,$returnType ='array')
    {
        $rawJsonContent = $request->getContent();
        if ($returnType == 'json') {
            return $rawJsonContent;
        } else {
            $content = json_decode($rawJsonContent,true);
            //$logger = $this->get('logger');
            //$logger->info('result content '.$content);
            //$logger->info('result rawJsonContent '.$rawJsonContent);
            if(is_array($content) && !empty($content)){
                //$logger->info('result valid content ');
                return $content;
            }else{
                return null;
            }
        }
        
    }
    
    /**
     * @return Hyper\EventBundle\Upload\EventLogUploader
     */
    protected function getEventLogUploader()
    {
        return $this->get('hyper_event.event_log_uploader');
    }
    
    protected function storeEventS3FromAPI(Request $request){
        $amazonBaseURL = $this->container->getParameter('hyper_event.amazon_s3.base_url');
        $rootDir = $this->get('kernel')->getRootDir();// '/var/www/html/projects/event_tracking/app'
        $rawLogDir = '/var/www/html/projects/event_tracking/web/raw_event';
         
        $fs = new Filesystem();
        $rawContent = $this->getValidContent($request,'json');
        $content = $this->getValidContent($request,'array');
        $appId=$content['app_id'];
        $eventType = $content['event_type'];
        $s3FolderMappping = $this->getS3FolderMapping();
        
        $result = $this->storeEventS3(
            $rawContent,
            $content,
            $amazonBaseURL,
            $rawLogDir,
            $s3FolderMappping
        );
        return $result;
        
    }
    
    public function storeEventS3(
        $rawContent,
        $content,
        $amazonBaseURL,
        $rawLogDir,
        $s3FolderMappping
    ) {   
        $year  = date('Y');
        $month = date('m');
        $day   = date('d');
        $hour  = date('H');
        $minute= date('i');
        
        $fs = new Filesystem();
        $appId=$content['app_id'];
        $eventType = $content['event_type'];
        $s3BucketFolder = '';
        if( array_key_exists($appId,$s3FolderMappping) ) {            
            $s3BucketFolder = $s3FolderMappping[$appId] ."/". $year ."/". $month ."/". $day ."/". $hour ."/". $minute;
        }
        $eventTime = $content['event_time'];
        $eventTimeStamp = strtotime($eventTime);
        $postBackProvider = ($this->postBackProvider!== null)?$this->postBackProvider:'';
        $uniqueId = uniqid();
        $path = $rawLogDir.'/'.$postBackProvider.'_'.$appId.'_'.$eventType.'_'.$eventTimeStamp.'_'.$uniqueId;
        $pathJson = $path.'.json';
        $pathGz = $path.'.gz';
        $fs->dumpFile($pathJson,$rawContent);
        
        $file = new File($pathJson);
       
        
        $filePathName = $file->getPathname();
        $gzFilePathName = $pathGz;
        file_put_contents($gzFilePathName, gzencode( file_get_contents($filePathName),9));
        chmod($gzFilePathName, 0777);
        $logger = $this->get('logger');
        $logger->info('file exist? '.$gzFilePathName.':'.file_exists($gzFilePathName));
        $gzFile = new File($gzFilePathName);
        
        $eventUploader = $this->getEventLogUploader();
        $region = $this->container->getParameter('amazon_s3_region');
        $bucket = $this->container->getParameter('amazon_s3_bucket_name');
        $securityKey = $this->container->getParameter('amazon_aws_key');
        $securitySecret = $this->container->getParameter('amazon_aws_secret_key');
        //userDefined metadata
        $metaData = array(
            'x-amz-meta-event_type' => $content['event_type'],
            'x-amz-meta-event_name' => $content['event_name']
        );
        //$fileName = $eventUploader->uploadFromLocalV2($gzFile,$s3BucketFolder);
        $fileName = $eventUploader->uploadFromLocalV3($gzFile,$s3BucketFolder,$region,$bucket,$securityKey,$securitySecret);
        if (!empty($fileName)) {
            $filePath = $amazonBaseURL.'/'.$fileName;
        
            //echo $fileName."<hr/>";
            $fs->remove($pathGz);
            $fs->remove($pathJson);

            // 2015-08-06  - Ding Dong: Commented line below so it won't be included in the result of CsvImportCommand::parseCsvContent()
            //echo $filePath;

            //return $filePath;
            return $fileName;

        } else {
            return null;
        }
        
    }
    
    public function S3FolderMapping(){
        return array(
            'com.bukalapak.android' => 'bukalapak',
            'id1003169137' => 'bukalapak',
            'com.daidigames.banting' => 'asianpoker',
            'id961876128' => 'asianpoker',
            'sg.gumi.bravefrontier' => 'bravefrontier',
            'id694609161' => 'bravefrontier',
            'sg.gumi.chainchronicleglobal' => 'chainchronicle',
            'id935189878' => 'chainchronicle',
            'sg.gumi.wakfu' => 'wakfu',
            'id942908715'   => 'wakfu',
            '_test' => '_test',
            'com.apn.mobile.browser' => 'askbrowser',
            'com.woi.liputan6.android' => 'liputan6',
            'com.google.android.apps.santatracker' => 'santatracker',
            'com.akasanet.yogrt.android' => 'yogrt',
            'id950197859' => 'yogrt',
            'id1049249612' => 'raiderquests',
            'com.tiket.gits' => 'tiket',
            'id890405921' => 'tiket'
        );
    }
    
    public function getS3FolderMapping() {
        return $this->S3FolderMapping();
    }
    
    // 2015-08-10 - Ding Dong : Removed CSV and added hasoffer
    public function postBackProviders() {
        return array(
            '1' => 'appsflyer',
            '2' => 'hasoffer',
            '3' => 'hypergrowth'
        );
    }
    
    public function getPostBackProviders(){
        return $this->postBackProviders();
    }
    
    public function getAmazonBaseURL(){
        return $this->container->getParameter('hyper_event.amazon_s3.base_url');
    }
}
