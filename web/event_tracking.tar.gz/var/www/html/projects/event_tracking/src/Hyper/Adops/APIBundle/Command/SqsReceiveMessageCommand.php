<?php
namespace Hyper\Adops\APIBundle\Command;

use Symfony\Bundle\FrameworkBundle\Command\ContainerAwareCommand;
use Symfony\Component\Console\Input\InputArgument;
use Symfony\Component\Console\Input\InputInterface;
use Symfony\Component\Console\Input\InputOption;
use Symfony\Component\Console\Output\OutputInterface;

use Aws\Sqs\SqsClient;
use GuzzleHttp\Client;
use Hyper\Adops\APIBundle\Controller\PostbackController;

class SqsReceiveMessageCommand extends ContainerAwareCommand
{
    private $sqsClient = null;
    
    protected function configure()
    {
        $this->setName('sqs:receive')
            ->setDescription('Receive Message From SQS!');
            // ->addOption(
            //     'queue_name',
            //     null,
            //     InputOption::VALUE_REQUIRED,
            //     'Queue Name'
            // );
    }
    
    protected function execute(InputInterface $input, OutputInterface $output)
    {
        // $queueName = $input->getOption('queue_name');
        $this->receiveFromSQS();
        
    }
    
    protected function setUpSQS()
    {
        if (null != $this->sqsClient) {
            return $this->sqsClient;
        }
        $sqsClient = SqsClient::factory(array(
            'region'  => 'us-west-2',
            'version' => 'latest',
            'credentials' => array(
                'key' => 'AKIAJLNAPSUVVCBGEAYQ',
                'secret'  => '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',
              )
        ));
        $this->sqsClient = $sqsClient;
        
        return $this->sqsClient;
    }
    
    protected function receiveFromSQS()
    {
        $adopsLogRepo = $this->getContainer()->get('adops.api.log.repository');
        $sqsClient = $this->setUpSQS();
        $result = $sqsClient->createQueue(array('QueueName' => 'test-queue'));
        $queueUrl = $result->get('QueueUrl');
        
        $result = $sqsClient->receiveMessage(array(
            'QueueUrl' => $queueUrl,
        ));
        if (isset($result['Messages'])) {
            foreach($result['Messages'] as $message) {
                $data = json_decode($message['Body'], true);
                $this->sendToPostback($data);
                
                $sqsClient->deleteMessage(array(
                    'QueueUrl'      => $queueUrl,
                    'ReceiptHandle' => $message['ReceiptHandle']
                ));
            }
        }
    }
    
    public function sendToPostback(array $data=[])
    {
        $adopsLogRepo = $this->getContainer()->get('adops.api.log.repository');

        if (!isset($data['af_siteid']) || !isset($data['app_id'])) {
            $adopsLogRepo->createAdopsLog(array(
                'detail' => array('error'=>'Miss argument af_siteid or app_id', 'data'=>$data)
            ));
            return ['status'=>false];
        }
        $params = array(
            'app_id' => $data['app_id'],
            'af_siteid' => $data['af_siteid'],
        );
        if ('aff_lsr' == $data['type']) {
            //: /adops/api/v1/post/aff_lsr?transaction_id={transaction_id}&af_siteid={af_siteid}&app_id={app_id}
            $params['event_type'] = 'install';
        } elseif('aff_goal' == $data['type']) {
            //: /adops/api/v1/post/aff_goal?a=lsr&goal_id={Free_text_event_name}&transaction_id={clickid}&af_siteid={af_siteid}&app_id={app_id}
            if (!isset($data['goal_id'])) {
                $adopsLogRepo->createAdopsLog(array(
                    'detail' => array('error'=>'Miss argument goal_id', 'data'=>$data)
                ));
            }
            $params['event_type'] = 'in-app-event';
            $params['event_name'] = $data['goal_id'];
        } else {
            $adopsLogRepo->createAdopsLog(array(
                'detail' => array('error'=>'Miss argument event type: aff_lsr or aff_goal', 'data' => $data)
            ));
            
            return ['status'=>false];
        }
        
        $adopsPostbackRepo = $this->getContainer()->get('adops.web.postback.repository');
        $postbacks = $adopsPostbackRepo->getPostbackCustom($params);
        if (count($postbacks) > 0) {
            
            //PUSH at here
            $rsSend = array();
            foreach ($postbacks as $postback) {
                $pbUrl = $postback['postback_url'];
                $client = new Client([
                    'timeout'  => 10.0,
                ]);
                $response = $client->request('POST', $pbUrl, [
                    'headers' => [
                        'Content-Type' => 'application/json',
                        'Accept'     => '*/*',
                    ],
                    'body' => json_encode($params)
                ]);
                
                $adopsLogRepo->createAdopsLog(array(
                    'detail' => $params,
                    'postback_id' => $postback['id'],
                    'postback_url' => $pbUrl,
                    'status' => $response->getStatusCode()
                ));
                
                array_push($rsSend, ['rs_status'=>$response->getStatusCode(), $postback]);
            }
            return ['status' => true, 'data' => $rsSend];
        }
        
        $adopsLogRepo->createAdopsLog(array(
            'detail' => array('error'=>'Not found Postback Entity', 'param'=>$params, 'data' => $data)
        ));
        
        return ['status' => false, 'message' => 'Not found!'];
    }
}