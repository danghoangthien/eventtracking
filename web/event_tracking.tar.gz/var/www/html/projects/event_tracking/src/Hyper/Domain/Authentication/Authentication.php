<?php

namespace Hyper\Domain\Authentication;

use Doctrine\ORM\Mapping as ORM;
use JMS\Serializer\Annotation\ExclusionPolicy;
use JMS\Serializer\Annotation\Expose;

/**
 * Authentication
 *
 * @ORM\Table(name="authentication")
 * @ORM\Entity(repositoryClass="Hyper\DomainBundle\Repository\Authentication\DTAuthenticationRepository")
 * @ExclusionPolicy("all")
 */
class Authentication
{
    const USER_TYPE_ADMIN = 1;
    const USER_TYPE_CLIENT = 0;
    const STATUS_ACTIVE = 1;
    const STATUS_INACTIVE = 0;
    
    public function __construct()
    {
        $this->id = uniqid('',true);    
        $this->updated = strtotime(date('Y-m-d h:i:s'));
    }
    
    /**
     * @ORM\Column(name="id", type="string", length=255, nullable=false)")
     * @ORM\Id
     * @Expose
     */
    protected $id;
    
    /**
     * @var string
     *
     * @ORM\Column(name="username", type="string", length=255, nullable=false)
     * @Expose
     */
    private $username;
    
    /**
     * @var string
     *
     * @ORM\Column(name="name", type="string", length=255, nullable=true)
     * @Expose
     */
    private $name;
    
    /**
     * @var string
     *
     * @ORM\Column(name="img_path", type="string", length=255, nullable=true)
     * @Expose
     */
    private $imgPath;

    /**
     * @var string
     *
     * @ORM\Column(name="password", type="string", length=255, nullable=false)
     * @Expose
     */
    private $password;
    
    /**
     * @var string
     *
     * @ORM\Column(name="email", type="string",nullable=false, length=255)
     * @Expose
     */
    private $email;
    
    /**
     * @var string
     *
     * @ORM\Column(name="application_id", type="string", length=13107, nullable=true)
     * @Expose
     */
    private $application_id;        
    
    /**
     * @var string
     *
     * @ORM\Column(name="client_id", type="string", length=13107, nullable=true)
     * @Expose
     */    
    private $clientId;
    
    /**
     * @var integer
     *
     * @ORM\Column(name="user_type", type="integer",options={"default"=0})
     * @Expose
     */
    private $userType;
    
    /**
     * @var integer
     *
     * @ORM\Column(name="status", type="integer",options={"default"=0})
     * @Expose
     */
    private $status;
    
    /**
     * @var string
     *
     * @ORM\Column(name="api_key", type="string", length=255, nullable=true)
     * @Expose
     */
    private $apiKey;
    
    /**
     * @var integer
     *
     * @ORM\Column(name="created", type="integer", nullable=false)
     * @Expose
     */
    private $created;
    
    /**
     * @var integer
     *
     * @ORM\Column(name="updated", type="integer", nullable=false,)
     * @Expose
     */
    private $updated;

    /**
     * Set id
     *
     * @param string $id
     * @return Authentication
     */
    public function setId($id)
    {
        $this->id = $id;

        return $this;
    }

    /**
     * Get id
     *
     * @return string 
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * Set username
     *
     * @param string $username
     * @return Authentication
     */
    public function setUsername($username)
    {
        $this->username = $username;

        return $this;
    }

    /**
     * Get username
     *
     * @return string 
     */
    public function getUsername()
    {
        return $this->username;
    }

    /**
     * Set name
     *
     * @param string $name
     * @return Authentication
     */
    public function setName($name)
    {
        $this->name = $name;

        return $this;
    }

    /**
     * Get name
     *
     * @return string 
     */
    public function getName()
    {
        return $this->name;
    }

    /**
     * Set imgPath
     *
     * @param string $imgPath
     * @return Authentication
     */
    public function setImgPath($imgPath)
    {
        $this->imgPath = $imgPath;

        return $this;
    }

    /**
     * Get imgPath
     *
     * @return string 
     */
    public function getImgPath()
    {
        return $this->imgPath;
    }

    /**
     * Set password
     *
     * @param string $password
     * @return Authentication
     */
    public function setPassword($password)
    {
        $this->password = $password;

        return $this;
    }

    /**
     * Get password
     *
     * @return string 
     */
    public function getPassword()
    {
        return $this->password;
    }

    /**
     * Set email
     *
     * @param string $email
     * @return Authentication
     */
    public function setEmail($email)
    {
        $this->email = $email;

        return $this;
    }

    /**
     * Get email
     *
     * @return string 
     */
    public function getEmail()
    {
        return $this->email;
    }

    /**
     * Set application_id
     *
     * @param string $applicationId
     * @return Authentication
     */
    public function setApplicationId($applicationId)
    {
        $this->application_id = $applicationId;

        return $this;
    }

    /**
     * Get application_id
     *
     * @return string 
     */
    public function getApplicationId()
    {
        return $this->application_id;
    }

    /**
     * Set clientId
     *
     * @param string $clientId
     * @return Authentication
     */
    public function setClientId($clientId)
    {
        $this->clientId = $clientId;

        return $this;
    }

    /**
     * Get clientId
     *
     * @return string 
     */
    public function getClientId()
    {
        return $this->clientId;
    }

    /**
     * Set userType
     *
     * @param integer $userType
     * @return Authentication
     */
    public function setUserType($userType)
    {
        $this->userType = $userType;

        return $this;
    }

    /**
     * Get userType
     *
     * @return integer 
     */
    public function getUserType()
    {
        return $this->userType;
    }

    /**
     * Set status
     *
     * @param integer $status
     * @return Authentication
     */
    public function setStatus($status)
    {
        $this->status = $status;

        return $this;
    }

    /**
     * Get status
     *
     * @return integer 
     */
    public function getStatus()
    {
        return $this->status;
    }

    /**
     * Set apiKey
     *
     * @param string $apiKey
     * @return Authentication
     */
    public function setApiKey($apiKey)
    {
        $this->apiKey = $apiKey;

        return $this;
    }

    /**
     * Get apiKey
     *
     * @return string 
     */
    public function getApiKey()
    {
        return $this->apiKey;
    }

    /**
     * Set created
     *
     * @param integer $created
     * @return Authentication
     */
    public function setCreated($created)
    {
        $this->created = $created;

        return $this;
    }

    /**
     * Get created
     *
     * @return integer 
     */
    public function getCreated()
    {
        return $this->created;
    }

    /**
     * Set updated
     *
     * @param integer $updated
     * @return Authentication
     */
    public function setUpdated($updated)
    {
        $this->updated = $updated;

        return $this;
    }

    /**
     * Get updated
     *
     * @return integer 
     */
    public function getUpdated()
    {
        return $this->updated;
    }
}
