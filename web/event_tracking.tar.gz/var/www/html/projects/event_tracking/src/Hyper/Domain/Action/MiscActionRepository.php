<?php 

namespace Hyper\Domain\Action;

interface MiscActionRepository {

}