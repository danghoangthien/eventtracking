<?php

namespace Hyper\Adops\APIBundle\Controller;

use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\HttpKernel\Exception\NotFoundHttpException;
use Symfony\Component\HttpKernel\Exception\BadRequestHttpException;
use Symfony\Component\HttpKernel\Exception\ConflictHttpException;

use FOS\RestBundle\Routing\ClassResourceInterface;
use FOS\RestBundle\Controller\FOSRestController;
use FOS\RestBundle\Request\ParamFetcherInterface;
use FOS\RestBundle\Controller\Annotations;
use FOS\RestBundle\Controller\Annotations\RequestParam;
use FOS\RestBundle\Controller\Annotations\QueryParam;
use FOS\RestBundle\Controller\Annotations\Post;
use FOS\RestBundle\Controller\Annotations\Get;
use FOS\RestBundle\Controller\Annotations\Put;
use FOS\RestBundle\Controller\Annotations\Delete;
use FOS\RestBundle\Controller\Annotations\Options;

use Aws\Sqs\SqsClient;

use GuzzleHttp\Client;
use Hyper\Adops\APIBundle\Domain\AdopsLog;

class PostbackController extends FOSRestController implements ClassResourceInterface
{
    private $sqsClient = null;

    /**
     * 
     * 
     * @Get("/{type}", name = "create", options = {"method_prefix" = false})
     *
     * @param Request $request param request to create new postback
     * @author Carl Pham <vanca.vnn@gmail.com>
     * @return array
     */
    public function getAction(Request $request, $type)
    {
        $data = $request->query->all();
        $data['type'] = $type;
        $this->sendToSQS($data);
        
        return ['status' => true]; 
        
        // $adopsLogRepo = $this->get('adops.api.log.repository');
        // $adopsLogRepo->createAdopsLog(array(
        //     'detail' => array('request'=>'This is request data', 'data' => $data)
        // ));

        // if (!isset($data['af_siteid']) || !isset($data['app_id'])) {
        //     $adopsLogRepo->createAdopsLog(array(
        //         'detail' => array('error'=>'Miss argument af_siteid or app_id', 'data'=>$data)
        //     ));
        //     return ['status'=>false];
        // }
        // $params = array(
        //     'app_id' => $data['app_id'],
        //     'af_siteid' => $data['af_siteid'],
        // );
        // if ('aff_lsr' == $type) {
        //     //: /adops/api/v1/post/aff_lsr?transaction_id={transaction_id}&af_siteid={af_siteid}&app_id={app_id}
        //     $params['event_type'] = 'install';
        // } elseif('aff_goal' == $type) {
        //     //: /adops/api/v1/post/aff_goal?a=lsr&goal_id={Free_text_event_name}&transaction_id={clickid}&af_siteid={af_siteid}&app_id={app_id}
        //     if (!isset($data['goal_id'])) {
        //         $adopsLogRepo->createAdopsLog(array(
        //             'detail' => array('error'=>'Miss argument goal_id', 'data'=>$data)
        //         ));
        //     }
        //     $params['event_type'] = 'in-app-event';
        //     $params['event_name'] = $data['goal_id'];
        // } else {
        //     $adopsLogRepo->createAdopsLog(array(
        //         'detail' => array('error'=>'Miss argument event type: aff_lsr or aff_goal', 'data' => $data)
        //     ));
            
        //     return ['status'=>false];
        // }
        
        // $adopsPostbackRepo = $this->get('adops.web.postback.repository');
        // $postbacks = $adopsPostbackRepo->getPostbackCustom($params);
        // if (count($postbacks) > 0) {
            
        //     //PUSH at here
        //     $rsSend = array();
        //     foreach ($postbacks as $postback) {
        //         $pbUrl = $postback['postback_url'];
        //         $client = new Client([
        //             'timeout'  => 2.0,
        //         ]);
        //         $response = $client->request('POST', $pbUrl, [
        //             'headers' => [
        //                 'Content-Type' => 'application/json',
        //                 'Accept'     => '*/*',
        //             ],
        //             'body' => json_encode($dataJson)
        //         ]);
                
        //         $adopsLogRepo->createAdopsLog(array(
        //             'detail' => $params,
        //             'postback_id' => $postback['id'],
        //             'postback_url' => $pbUrl,
        //             'status' => $response->getStatusCode()
        //         ));
                
        //         array_push($rsSend, ['rs_status'=>$response->getStatusCode(), $postback]);
        //     }
        //     return ['status' => true, 'data' => $rsSend];
        // }
        
        // $adopsLogRepo->createAdopsLog(array(
        //     'detail' => array('error'=>'Not found Postback Entity', 'param'=>$params, 'data' => $data)
        // ));
        
        // return ['status' => false, 'message' => 'Not found!'];
    }
    
    protected function setUpSQS()
    {
        if (null != $this->sqsClient) {
            return $this->sqsClient;
        }
        $sqsClient = SqsClient::factory(array(
            'region'  => 'us-west-2',
            'version' => 'latest',
            'credentials' => array(
                'key' => 'AKIAJLNAPSUVVCBGEAYQ',
                'secret'  => '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',
              )
        ));
        $this->sqsClient = $sqsClient;
        
        return $this->sqsClient;
    }
    
    protected function sendToSQS(array $data=[])
    {
        $sqsClient = $this->setUpSQS();
        $result = $sqsClient->createQueue(array('QueueName' => 'test-queue'));
        $queueUrl = $result->get('QueueUrl');
        $sqsClient->sendMessage(array(
            'QueueUrl'    => $queueUrl,
            'MessageBody' => json_encode($data),
        ));
    }
    
}
