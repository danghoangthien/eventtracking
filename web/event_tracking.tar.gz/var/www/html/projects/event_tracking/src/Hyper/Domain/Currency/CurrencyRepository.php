<?php 

namespace Hyper\Domain\Currency;

interface CurrencyRepository {

}
