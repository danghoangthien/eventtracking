<?php 

namespace Hyper\Domain\Action;

interface ActionRepository {

}