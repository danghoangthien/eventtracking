<?php

namespace Hyper\EventBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class HyperEventBundle extends Bundle
{
}
