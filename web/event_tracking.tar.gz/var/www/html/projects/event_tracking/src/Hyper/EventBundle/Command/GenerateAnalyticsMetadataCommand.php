<?php
namespace Hyper\EventBundle\Command;

use Symfony\Bundle\FrameworkBundle\Command\ContainerAwareCommand;
use Symfony\Component\Console\Input\InputArgument;
use Symfony\Component\Console\Input\InputInterface;
use Symfony\Component\Console\Input\InputOption;
use Symfony\Component\Console\Output\OutputInterface;

class GenerateAnalyticsMetadataCommand extends ContainerAwareCommand
{
    protected function configure()
    {
        $this
            ->setName('analytics_metadata:generate')
            ->setDescription('generate meta data metadata');
    }
    
    protected function execute(InputInterface $input, OutputInterface $output)
    {
            echo "generating Metadata.<br/>";
            echo "start @ ".date('d-m-Y H:i:s')."\n";
            //die;
            $analyticsController = $this->getContainer()->get('analytics.controller');
            $key = "profiles_breakdown_by_eventplatform";
            $analyticsController->generateMetadataValues($key);
            //$analyticsController->generateMetadataRows();
            echo "end @ ".date('d-m-Y H:i:s')."\n";

    }
    
}