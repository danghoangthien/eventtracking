<?php 

namespace Hyper\Domain\Item;

interface InCartItemRepository {

}