<?php 

namespace Hyper\Domain\Category;

interface CategoryRepository {

}