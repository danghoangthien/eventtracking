<?php
namespace Hyper\EventBundle\Command;

use Symfony\Bundle\FrameworkBundle\Command\ContainerAwareCommand;
use Symfony\Component\Console\Input\InputArgument;
use Symfony\Component\Console\Input\InputInterface;
use Symfony\Component\Console\Input\InputOption;
use Symfony\Component\Console\Output\OutputInterface;

class RedshiftBatchProcessingCommand extends ContainerAwareCommand
{
    protected function configure()
    {
        $this
            ->setName('redshift:batch')
            ->setDescription('generate frm from transaction actions');
    }
    
    protected function execute(InputInterface $input, OutputInterface $output)
    {
            echo "generating FRM.<br/>";
            $start = date('d-m-Y H:i:s');
            echo "start @ ".$start."\n";
            $redshiftBatchProcessing = $this->getContainer()->get('redshift_batch_processing_service');
            $redshiftBatchProcessing->init();
            $redshiftBatchProcessing->processV2(true);
            echo "start @ ".$start."\n";
            echo "end @ ".date('d-m-Y H:i:s')."\n";

    }
    
}