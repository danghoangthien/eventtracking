<?php
namespace Hyper\EventBundle\Command;

class PersonStorageCommand
{
    
}