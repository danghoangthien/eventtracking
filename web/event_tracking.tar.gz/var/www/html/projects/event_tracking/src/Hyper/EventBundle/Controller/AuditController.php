<?php

namespace Hyper\EventBundle\Controller;

use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Symfony\Component\DependencyInjection\ContainerInterface;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;


class AuditController extends Controller
{
    /**
    * @param ContainerInterface $container
    */
    public function __construct(ContainerInterface $container)
    {
        $this->container = $container;
    }
    
    public function indexAction(Request $request)
    {

    }
    
    public function showAction(Request $request)
    {
        $auditLogRepo = $this->container->get('audit_repository');
        $page = $request->get('page');
        //$page = 0;
        $rpp = 5;
        $auditType = $request->get('audit_type');
        $result = $auditLogRepo->getResultAndCount($page,$rpp,$auditType);
        $rows = $result['rows'];
        $totalCount = $result['total'];
        $paginator = new \lib\Paginator($page, $totalCount, $rpp);
        $pageList = $paginator->getPagesList();
        return $this->render('audit/audit_index.html.twig', 
            array(
                'rows' => $rows, 
                'paginator' => $pageList, 
                'cur' => $page, 
                'total' => $paginator->getTotalPages(), 
                'audit_type'=>$auditType
                )
        );
    }

}
