<?php 

namespace Hyper\Domain\Filter;

interface FilterRepository {

}