<?php 

namespace Hyper\Domain\Client;

interface ClientRepository {

}