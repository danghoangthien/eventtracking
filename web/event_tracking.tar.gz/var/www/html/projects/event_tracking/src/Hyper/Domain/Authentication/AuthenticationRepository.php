<?php 

namespace Hyper\Domain\Authentication;

interface AuthenticationRepository {

}