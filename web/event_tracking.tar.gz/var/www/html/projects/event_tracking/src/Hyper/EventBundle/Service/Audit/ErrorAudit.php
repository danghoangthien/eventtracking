<?php
namespace Hyper\EventBundle\Service\Audit;

//Container
use Symfony\Component\DependencyInjection\ContainerInterface;

class ErrorAudit
{
    public $container;
    public $logType;// redshift,memcache,monolog,...
    public $request;
    
    public function __construct(ContainerInterface $container){
        $this->container = $container;
        if ($container->isScopeActive('request')) {
            $this->request = $this->container->get('request');
        } else {
            $this->request = null;
        }
        
    }
    
    public function init($logType) {
        $this->logType = $logType;
    }
    
    public function dump() {
        $lastError = error_get_last();
        var_dump($lastError);
        return $lastError;
    }
    
    public function log() {
        $lastError = error_get_last();
        //var_dump($lastError);die;
        if ($this->logType == 'Redshift' && !empty($lastError) && $lastError['type']!='8192'){
            //log into Redshift audit
            $auditLogRepo = $this->container->get('audit_repository');
            $auditLog = new \Hyper\Domain\Audit\Audit();
            $auditLog->setAuditType(\Hyper\Domain\Audit\Audit::ERROR_AUDIT_TYPE);
            
            if ($this->request!= null) {
                $headers = $this->request->headers->all();
                $requestURL = $this->request->getUri();
                $method = $this->request->getMethod();
                $all = $this->request->request->all();
            } else {
                $headers = array();
                $requestURL = '';
                $method = '';
                $all = array();
            }
            
            $auditLog->setRequestHeader($headers);
            
            $auditLog->setRequestUrl($requestURL);

            $auditLog->setRequestMethod($method);
            
            if ($method == 'GET') {
                $requestContent = array(
                   //'params'=>$_GET
                );
            } elseif ($method == 'POST') {
                $requestContent = array(
                    'params'=>$all
                );
            } else {
                $requestContent = array();
            }
            
            $auditLog->setRequestContent($requestContent);
            
            $auditLog->setResponseBody('');
            $responseHeader = headers_list();
            $auditLog->setResponseHeader($responseHeader);
            $responseHTTPCode = http_response_code();
            
            $auditLog->setResponseHTTPCode($responseHTTPCode);
            
            $auditLog->setBenchmark(array());
            $auditLog->setException(array());
            
            $auditLog->setError($lastError);
            $auditLogRepo->save($auditLog);

            //\Doctrine\Common\Util\Debug::dump($auditLog);
            $auditLogRepo->completeTransaction();
            
        }
        
    }
}