<?php 

namespace Hyper\Domain\Action;

interface ViewContentActionRepository {

}