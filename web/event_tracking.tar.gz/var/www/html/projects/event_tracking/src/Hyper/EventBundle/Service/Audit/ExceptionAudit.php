<?php
namespace Hyper\EventBundle\Service\Audit;

//Container
use Symfony\Component\DependencyInjection\ContainerInterface;

class ExceptionAudit
{
    public $container;
    public $logType;// redshift,memcache,monolog,...
    public $request;
    public $exception;
    
    public function __construct(ContainerInterface $container){
        $this->container = $container;
        if ($container->isScopeActive('request')) {
            $this->request = $this->container->get('request');
        } else {
            $this->request = null;
        }
        
    }
    
    public function init($logType,\Exception $exception) {
        $this->logType = $logType;
        
        $this->exception = $exception;
    }
    
    public function dump() {
        $exception = $this->exception;
        var_dump($exception);
        return $exception;
    }
    
    public function log() {
        //force reset entity manager,it might close when error or exception occured
        //$em=$this->container->get('doctrine')->resetManager('pgsql');
        $lastError = error_get_last();
        if ($this->logType == 'Redshift'){
            //log into Redshift audit
            $auditLogRepo = $this->container->get('audit_repository');
            $auditLog = new \Hyper\Domain\Audit\Audit();
            $auditLog->setAuditType(\Hyper\Domain\Audit\Audit::EXCEPTION_AUDIT_TYPE);
            if ($this->request!= null) {
                $headers = $this->request->headers->all();
                $requestURL = $this->request->getUri();
                $method = $this->request->getMethod();
                $all = $this->request->request->all();
            } else {
                $headers = array();
                $requestURL = '';
                $method = '';
                $all = array();
            }
            
            $auditLog->setRequestHeader($headers);
            
            $auditLog->setRequestUrl($requestURL);
            
            $auditLog->setRequestMethod($method);
            
            if ($method == 'GET') {
                 $requestContent = array(
                    //'params'=>$_GET
                );
            } elseif ($method == 'POST') {
                $requestContent = array(
                    'params'=>$all
                );
            } else {
                $requestContent = array();
            }
            
            $auditLog->setRequestContent($requestContent);
            
            $auditLog->setResponseBody('');
            $responseHeader = headers_list();
            $auditLog->setResponseHeader($responseHeader);
            $responseHTTPCode = http_response_code();
            
            $auditLog->setResponseHTTPCode($responseHTTPCode);
            
            $auditLog->setBenchmark(array());
            $exception = $this->exception;
            $exception = array(
                'message' => $this->exception->getMessage(),
                'code' => $this->exception->getCode(),
                'file' => $this->exception->getFile(),
                'line' => $this->exception->getLine(),
            );
            //print_r($exception);die;
            $auditLog->setException($exception);
            
            $auditLog->setError(array());
            $auditLogRepo->save($auditLog);

            //\Doctrine\Common\Util\Debug::dump($auditLog);
            $auditLogRepo->completeTransaction();
            
        }
        
    }
}