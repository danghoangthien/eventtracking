<?php
namespace Hyper\EventBundle\Controller\Dashboard\Analytics;

use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Symfony\Component\DependencyInjection\ContainerInterface;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;

// entities
use Hyper\Domain\Analytics\Metadata;
// Doctrine
use Doctrine\Common\Annotations\AnnotationReader;
use Doctrine\DBAL\Driver\PDOStatement;

class AnalyticsController extends Controller
{

    /**
    * @param ContainerInterface $container
    */
    public function __construct(ContainerInterface $container)
    {
        $this->container = $container;
    }
    
    public function getByKeyAction(Request $request)
    {
        $data = null;
        $key = $request->get('key');
        $metadataRepository = $this->get('analytics_metadata_repository');
        $metadata = $metadataRepository->findOneByKey($key);
        //echo $key."<br/>";
        //var_dump($metadata);
        if ($metadata instanceof Metadata) {
           // echo "Instance of metadata <hr/>";
            $data = $metadata->getMetadata();
            $data = json_decode($data,true);
        } else {
            $data = null;
        }
        
        
        $response = new Response(
                        json_encode(
                            array(
                                'data' => $data
                            )
                        )
                    );
        $response->headers->set('Access-Control-Allow-Origin', '*');
        return $response;
    }
    
    public function generateMetadataValues($key = null)
    {
        $metadataRepository = $this->get('analytics_metadata_repository');
        $metadatas = $metadataRepository->findAll();
        foreach ($metadatas as $metadata) {
            if ($key !=null && $key != $metadata->getKey()){
                echo "Skip processing : ".$metadata->getKey(). "\n";
                continue;
            } else {
                echo "Processing : ".$metadata->getKey(). "\n";
                $query = $metadata->getQuery();
                $conn = $this->get('doctrine.dbal.pgsql_connection');                                    
                $sql  = $conn->prepare($query);                      
                $sql->execute();
                $data = array();
                for($x = 0; $row = $sql->fetch(); $x++) 
                {
                    $data[] = $row;
                }
                $jsonMetadata = json_encode($data);
                $metadata->setMetadata($jsonMetadata);
                $metadataRepository->save($metadata);
                $metadataRepository->completeTransaction();
                echo "Done : ".$metadata->getKey(). "\n";
            }
            
        }
    }
    
    public function generateMetadataRows()
    {   //die;
        
        $metadataRepository = $this->get('analytics_metadata_repository');
        /*
        //profiles_breakdown_by_app_source
        $metadata = new Metadata();
        $metadata->setKey('profiles_breakdown_by_app_source');
        $query = "SELECT
                count(distinct(actions.device_id)) as device_id,
                case 
                when applications.app_name IN ('Chain Chronicle - Line Defense RPG','Chain Chronicle – RPG') then 'Chain Chronicle'
                when applications.app_name = 'Liputan6.com' then 'Liputan6'
                when applications.app_name = 'Asian Poker - Big Two' then 'Asian Poker'
                when applications.app_name = 'Bukalapak - Jual Beli Online' then 'Bukalapak'
                when applications.app_name= 'Yogrt: Meet Friends Nearby' then 'Yogrt'
                else applications.app_name
                end as app_name
                FROM
                applications 
                INNER JOIN actions actions ON applications.app_id = actions.app_id
                WHERE actions.app_id is not null AND app_name != '[App Name Comes Here]'
                GROUP BY app_name";
        $metadata->setQuery($query);
        $metadata->setDataSource(Metadata::DATA_SOURCE_JSON);
        $metadata->setMetadata('');
        $metadataRepository->save($metadata);
        
        //profiles_breakdown_by_platform
        $metadata = new Metadata();
        $metadata->setKey('profiles_breakdown_by_platform');
        $query = "SELECT
                count(distinct(actions.device_id)) as device_id,
                case 
                         when devices.platform =  '1' then 'iOS'
                         when devices.platform =  '2' then 'Android'
                end as platform
                FROM
                     devices 
                INNER JOIN actions actions ON devices.id = actions.device_id
                GROUP BY devices.platform";
        $metadata->setQuery($query);
        $metadata->setDataSource(Metadata::DATA_SOURCE_JSON);
        $metadata->setMetadata('');
        $metadataRepository->save($metadata);
        
        //profiles_breakdown_by_sourceplatform
        $metadata = new Metadata();
        $metadata->setKey('profiles_breakdown_by_sourceplatform');
        $query = "SELECT
             count(distinct(actions.device_id)) as device_id,
             case
                             when devices.platform = '1' then 'iOS'
                        when devices.platform = '2' then 'Android'
                        end as platform,
             case 
             when applications.app_name IN ('Chain Chronicle - Line Defense RPG','Chain Chronicle – RPG') then 'Chain Chronicle'
             when applications.app_name = 'Liputan6.com' then 'Liputan6'
             when applications.app_name = 'Asian Poker - Big Two' then 'Asian Poker'
             when applications.app_name = 'Bukalapak - Jual Beli Online' then 'Bukalapak'
             when applications.app_name = 'Yogrt: Meet Friends Nearby' then 'Yogrt'
             else applications.app_name
             end as app_name
            FROM
                 applications 
            INNER JOIN actions ON applications.app_id = actions.app_id
            INNER JOIN devices ON actions.device_id = devices.id
            WHERE actions.app_id is not null AND app_name != '[App Name Comes Here]'
            GROUP BY app_name, devices.platform";
        $metadata->setQuery($query);
        $metadata->setDataSource(Metadata::DATA_SOURCE_JSON);
        $metadata->setMetadata('');
        $metadataRepository->save($metadata);
        
        
        //profiles_breakdown_by_event_yogrt
        $metadata = new Metadata();
        $metadata->setKey('profiles_breakdown_by_event_yogrt');
        $query = "SELECT
                    count(distinct(actions.device_id)) as device_id,
                    actions.app_id,
                    case
                             when actions.behaviour_id = '1' then 'install'
                             when actions.behaviour_id = '10' then 'register'
                             end as event_name,
                    case
                                when devices.platform = '1' then 'iOS'
                                when devices.platform = '2' then 'Android'
                                end as platform
                FROM
                    applications 
                INNER JOIN actions ON applications.app_id = actions.app_id
                INNER JOIN devices ON actions.device_id = devices.id
                WHERE actions.app_id IN ('com.akasanet.yogrt.android','id950197859')
                GROUP BY devices.platform, actions.app_id, event_name
                ";
        $metadata->setQuery($query);
        $metadata->setDataSource(Metadata::DATA_SOURCE_JSON);
        $metadata->setMetadata('');
        $metadataRepository->save($metadata);
        */
        //profiles_breakdown_by_country
        $metadata = new Metadata();
        $metadata->setKey('profiles_breakdown_by_eventplatform');
        $query ="SELECT
    device_id,
    count(device_id) as pcount,
    app_id,
    date(TIMESTAMP 'epoch' + happened_at * INTERVAL '1 Second ') as event_date,
    behaviour_id    
FROM
     actions
WHERE  date(TIMESTAMP 'epoch' + happened_at * INTERVAL '1 Second ') > (current_date - integer '7')
GROUP BY app_id, behaviour_id, event_date, device_id
                ";
        $metadata->setQuery($query);
        $metadata->setDataSource(Metadata::DATA_SOURCE_JSON);
        $metadata->setMetadata('');
        $metadataRepository->save($metadata);
        $metadataRepository->completeTransaction();
        /*
        $metadata = new Metadata();
        $metadata->setKey('profiles_breakdown_by_country_raidersquest');
        $query ="SELECT 
            count(distinct(id)) as device_id, 
            devices.country_code AS country_name,
            CASE
                  when devices.platform = '1' then 'iOS'
                  when devices.platform = '2' then 'Android'
                  end as platform
            FROM devices 
            WHERE id  in (select device_id from actions where app_id = 'id1049249612')  
            GROUP BY devices.platform, devices.country_code ";
        $metadata->setQuery($query);
        $metadata->setDataSource(Metadata::DATA_SOURCE_JSON);
        $metadata->setMetadata('');
        $metadataRepository->save($metadata);
        $metadataRepository->completeTransaction();
        /*
        //profiles_breakdown_by_country
        $metadata = $metadataRepository->findOneByKey('profiles_breakdown_by_country');

        $query ="
select count(distinct(id)) as device_id, 
			devices.country_code AS country_name,
      case
                 when devices.platform = '1' then 'iOS'
            when devices.platform = '2' then 'Android'
            end as platform
       from devices 
       where id  in (select device_id from actions)  
       GROUP BY devices.platform,devices.country_code;
                ";
        $metadata->setQuery($query);
        $metadataRepository->save($metadata);
        $metadataRepository->completeTransaction();
        */
    }
    

    
}
