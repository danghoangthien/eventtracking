<?php

namespace Hyper\Domain\Audit;

use Doctrine\ORM\Mapping as ORM;
use Symfony\Component\Validator\Constraints as Assert;
use JMS\Serializer\Annotation\ExclusionPolicy;
use JMS\Serializer\Annotation\Expose;

/**
 * Audit
 *
 * @ORM\Table(name="audits")
 * @ORM\Entity(repositoryClass="Hyper\DomainBundle\Repository\Audit\DTAuditRepository")
 * @ExclusionPolicy("all")
 */
class Audit
{
    const ERROR_AUDIT_TYPE = 1;
    const EXCEPTION_AUDIT_TYPE = 2;
    const BENCHMARK_AUDIT_TYPE = 3;
    
    /**
     * @var string
     * @ORM\Column(name="id", type="string", options={"unsigned"=true})
     * @ORM\Id
     * @Expose
     */
    private $id;
    
    /**
     * @var integer
     *
     * @ORM\Column(name="audit_type", type="integer",options={"default"=0})
     * @Expose
     */
    private $auditType;

    /**
     * @var string
     *
     * @ORM\Column(name="request_header", type="string", length=65535)
     * @Expose
     */
    private $requestHeader;

    /**
     * @var string
     *
     * @ORM\Column(name="request_url", type="string")
     * @Expose
     */
    private $requestUrl;
    
    /**
     * @var string
     *
     * @ORM\Column(name="request_method", type="string")
     * @Expose
     */
    private $requestMethod;

    /**
     * @var string
     *
     * @ORM\Column(name="request_content", type="string", length=65535)
     * @Expose
     */
    private $requestContent;
    
    /**
     * @var array
     *
     * @ORM\Column(name="response_header", type="string", length=65535)
     * @Expose
     */
    private $responseHeader;
    
    /**
     * @var string
     *
     * @ORM\Column(name="response_body", type="string", length=65535)
     * @Expose
     */
    private $responseBody;
    
    /**
     * @var integer
     *
     * @ORM\Column(name="response_http_code", type="integer")
     * @Expose
     */
    private $responseHTTPCode;
    

    /**
     * @var string
     *
     * @ORM\Column(name="benchmark", type="string", length=65535)
     * @Expose
     */
    private $benchmark;
    
    /**
     * @var string
     *
     * @ORM\Column(name="exception", type="string" , length=65535)
     * @Expose
     */
    private $exception;
    
    /**
     * @var string
     *
     * @ORM\Column(name="error", type="string", length=65535)
     * @Expose
     */
    private $error;
    
    /**
     * @var integer
     *
     * @ORM\Column(name="created", type="integer")
     * @Expose
     */
    private $created;
    
    public function __construct()
    {
        $this->id = uniqid('',true);
        $this->created = time();
    }
    

    /**
     * Set id
     *
     * @param string $id
     * @return Audit
     */
    public function setId($id)
    {
        $this->id = $id;

        return $this;
    }

    /**
     * Get id
     *
     * @return string 
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * Set requestHeader
     *
     * @param string $requestHeader
     * @return Audit
     */
    public function setRequestHeader($requestHeader)
    {
        $this->requestHeader = serialize($requestHeader);

        return $this;
    }

    /**
     * Get requestHeader
     *
     * @return string 
     */
    public function getRequestHeader()
    {
        return unserialize($this->requestHeader);
    }

    /**
     * Set requestUrl
     *
     * @param string $requestUrl
     * @return Audit
     */
    public function setRequestUrl($requestUrl)
    {
        $this->requestUrl = $requestUrl;

        return $this;
    }

    /**
     * Get requestUrl
     *
     * @return string 
     */
    public function getRequestUrl()
    {
        return $this->requestUrl;
    }

    /**
     * Set requestMethod
     *
     * @param string $requestMethod
     * @return Audit
     */
    public function setRequestMethod($requestMethod)
    {
        $this->requestMethod = $requestMethod;

        return $this;
    }

    /**
     * Get requestMethod
     *
     * @return string 
     */
    public function getRequestMethod()
    {
        return $this->requestMethod;
    }

    /**
     * Set requestContent
     *
     * @param string $requestContent
     * @return Audit
     */
    public function setRequestContent($requestContent)
    {
        $this->requestContent = serialize($requestContent);

        return $this;
    }

    /**
     * Get requestContent
     *
     * @return string 
     */
    public function getRequestContent()
    {
        return unserialize($this->requestContent);
    }

    /**
     * Set responseHeader
     *
     * @param string $responseHeader
     * @return Audit
     */
    public function setResponseHeader($responseHeader)
    {
        $this->responseHeader = serialize($responseHeader);

        return $this;
    }

    /**
     * Get responseHeader
     *
     * @return string 
     */
    public function getResponseHeader()
    {
        return unserialize($this->responseHeader);
    }

    /**
     * Set responseBody
     *
     * @param string $responseBody
     * @return Audit
     */
    public function setResponseBody($responseBody)
    {
        $this->responseBody = $responseBody;

        return $this;
    }

    /**
     * Get responseBody
     *
     * @return string 
     */
    public function getResponseBody()
    {
        return $this->responseBody;
    }

    /**
     * Set responseHTTPCode
     *
     * @param integer $responseHTTPCode
     * @return Audit
     */
    public function setResponseHTTPCode($responseHTTPCode)
    {
        $this->responseHTTPCode = $responseHTTPCode;

        return $this;
    }

    /**
     * Get responseHTTPCode
     *
     * @return integer 
     */
    public function getResponseHTTPCode()
    {
        return $this->responseHTTPCode;
    }

    /**
     * Set benchmark
     *
     * @param string $benchmark
     * @return Audit
     */
    public function setBenchmark($benchmark)
    {
        $this->benchmark = serialize($benchmark);

        return $this;
    }

    /**
     * Get benchmark
     *
     * @return string 
     */
    public function getBenchmark()
    {
        return unserialize($this->benchmark);
    }

    /**
     * Set exception
     *
     * @param string $exception
     * @return Audit
     */
    public function setException($exception)
    {
        $this->exception = serialize($exception);

        return $this;
    }

    /**
     * Get exception
     *
     * @return string 
     */
    public function getException()
    {
        return unserialize($this->exception);
    }

    /**
     * Set error
     *
     * @param string $error
     * @return Audit
     */
    public function setError($error)
    {
        $this->error = serialize($error);

        return $this;
    }

    /**
     * Get error
     *
     * @return string 
     */
    public function getError()
    {
        return unserialize($this->error);
    }

    /**
     * Set created
     *
     * @param integer $created
     * @return Audit
     */
    public function setCreated($created)
    {
        $this->created = $created;

        return $this;
    }

    /**
     * Get created
     *
     * @return integer 
     */
    public function getCreated()
    {
        return $this->created;
    }

    /**
     * Set auditType
     *
     * @param integer $auditType
     * @return Audit
     */
    public function setAuditType($auditType)
    {
        $this->auditType = $auditType;

        return $this;
    }

    /**
     * Get auditType
     *
     * @return integer 
     */
    public function getAuditType()
    {
        return $this->auditType;
    }
}
