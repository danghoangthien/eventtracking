<?php 

namespace Hyper\Domain\Promo;

interface PromoRepository {

}