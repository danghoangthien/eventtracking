<?php 

namespace Hyper\Domain\Device;

interface AndroidDeviceRepository {

}