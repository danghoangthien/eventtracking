<?php 

namespace Hyper\Domain\Content;

interface ContentRepository {

}