<?php 

namespace Hyper\Domain\Action;

interface LaunchActionRepository {

}