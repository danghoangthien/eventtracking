<?php 

namespace Hyper\Domain\Jasper;

interface JasperRepository {

}