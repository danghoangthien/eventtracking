<?php 

namespace Hyper\Domain\Promo_landing;

interface PromoLandingRepository {

}