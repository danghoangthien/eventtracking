<?php 

namespace Hyper\Domain\Action;

interface SearchActionRepository {

}