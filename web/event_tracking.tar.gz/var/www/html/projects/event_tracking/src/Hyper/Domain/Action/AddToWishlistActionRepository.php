<?php 

namespace Hyper\Domain\Action;

interface AddToWishlistActionRepository {

}