<?php 

namespace Hyper\Domain\Device;

interface IOSDeviceRepository {

}