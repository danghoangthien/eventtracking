<?php 

namespace Hyper\Domain\Content;

interface InCategoryContentRepository {

}