<?php 

namespace Hyper\Domain\Setting;

interface SettingRepository {

}