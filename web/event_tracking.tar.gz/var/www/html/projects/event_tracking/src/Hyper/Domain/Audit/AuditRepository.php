<?php 

namespace Hyper\Domain\Audit;

interface AuditRepository {

}