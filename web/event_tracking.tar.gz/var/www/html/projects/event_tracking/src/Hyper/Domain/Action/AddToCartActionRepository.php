<?php 

namespace Hyper\Domain\Action;

interface AddToCartActionRepository {

}