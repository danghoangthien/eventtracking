<?php 

namespace Hyper\Domain\Item;

interface InWishlistItemRepository {

}