<?php 

namespace Hyper\Domain\Item;

interface ItemRepository {

}