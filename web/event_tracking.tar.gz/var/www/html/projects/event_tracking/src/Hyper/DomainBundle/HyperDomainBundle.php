<?php

namespace Hyper\DomainBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class HyperDomainBundle extends Bundle
{
}
