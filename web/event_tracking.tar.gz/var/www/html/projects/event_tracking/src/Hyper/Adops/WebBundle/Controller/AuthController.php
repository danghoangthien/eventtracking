<?php

namespace Hyper\Adops\WebBundle\Controller;

use Sensio\Bundle\FrameworkExtraBundle\Configuration\Route;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Method;
use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\Form\Extension\Core\ChoiceList\ChoiceList;


/**
 * @author Carl Pham <vanca.vnn@gmail.com>
 */
class AuthController extends Controller
{
    /**
     * @Route("/adops/login", name="adops_login")
     * @Method({"GET", "POST"})
     */
    public function indexAction(Request $request)
    {
        $form = $this->createFormBuilder()
                ->add('user_name', 'text', ['label' => 'User Name'])
                ->add('password', 'password', ['label' => 'Passwords'])
                ->add('save', 'submit', ['label' => 'Login'])
                ->getForm();
        $form->handleRequest($request);
        if ($form->isSubmitted() && $form->isValid()) {
            $data = $form->getData();
            if ('admin' == $data['user_name'] && 'hypergrowth' == $data['password']) {
                $session = $this->getRequest()->getSession();
                $session->set('user_logined', 'true');
                $session->save();
                return $this->redirectToRoute('applications');
            }
        }
        return $this->render('adops/adops_login.html.twig', ['form' => $form->createView()]);
    }
    
    /**
     * @Route("/adops/logout", name="adops_logout")
     * @Method({"GET", "POST"})
     */
    public function logoutAction(Request $request)
    {
        $session = $this->getRequest()->getSession();
        if ($session->has('user_logined')) {
            $session->remove('user_logined');
            $session->save();
        }
        
        return $this->redirectToRoute('adops_login');
    }

}
