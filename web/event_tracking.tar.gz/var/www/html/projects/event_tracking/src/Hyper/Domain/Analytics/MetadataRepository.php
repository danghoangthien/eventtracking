<?php 

namespace Hyper\Domain\Analytics;

interface MetadataRepository {

}