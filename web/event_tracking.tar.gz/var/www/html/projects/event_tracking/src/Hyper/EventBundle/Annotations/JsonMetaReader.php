<?php
namespace Hyper\EventBundle\Annotations;
use Doctrine\Common\Annotations\AnnotationReader;

class JsonMetaReader {
    
    public function jsonMetaField() {
        
    }
    
}
