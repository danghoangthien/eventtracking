<?php 

namespace Hyper\Domain\Action;

interface InstallActionRepository {

}