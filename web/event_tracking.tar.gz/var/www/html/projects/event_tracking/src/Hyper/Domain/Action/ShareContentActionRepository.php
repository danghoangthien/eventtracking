<?php 

namespace Hyper\Domain\Action;

interface ShareContentActionRepository {

}