<?php 

namespace Hyper\Domain\Action;

interface TransactionActionRepository {

}