<?php

namespace Hyper\Adops\WebBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class HyperAdopsWebBundle extends Bundle
{
}