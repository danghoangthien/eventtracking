<?php 

namespace Hyper\Domain\Promo_placement;

interface PromoPlacementRepository {

}