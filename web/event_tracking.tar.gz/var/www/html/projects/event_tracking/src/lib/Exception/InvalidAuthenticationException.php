<?php
namespace lib\Exception;

class InvalidAuthenticationException extends \LogicException
{

}