<?php 

namespace Hyper\Domain\Item;

interface TransactedItemRepository {

}